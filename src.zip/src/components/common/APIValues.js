export default {
    URL: 'https://farmar.in/api/'
    //URL: 'http://demo.farmar.in/api/'
    //URL: 'http://localhost:51878/api/'
    //URL: 'http://conferencepresentations.in/api/'
}